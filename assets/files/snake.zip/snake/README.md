# snake
Classic snake game developed in python usign pygame library
